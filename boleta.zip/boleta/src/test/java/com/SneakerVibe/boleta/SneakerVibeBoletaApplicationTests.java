package com.SneakerVibe.boleta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SneakerVibeBoletaApplicationTests {

	@Test
	void contextLoads() {
	}

}
