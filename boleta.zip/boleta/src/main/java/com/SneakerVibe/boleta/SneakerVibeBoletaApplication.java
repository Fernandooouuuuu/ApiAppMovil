package com.SneakerVibe.boleta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SneakerVibeBoletaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SneakerVibeBoletaApplication.class, args);
	}

}
